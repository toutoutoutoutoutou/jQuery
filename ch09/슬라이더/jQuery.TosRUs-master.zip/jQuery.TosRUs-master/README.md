jQuery.TosRUs
================

A one-stop-shop jQuery plugin for scrolling/swiping through all different kinds of content.
On a desktop, tablet or smartphone, inside a HTML element or as a lightbox popup.

*Note:
This plugin has been superseded by other plugins and is therefor no longer actively maintained.*

<img src="http://tosrus.frebsite.nl/img/preview-3.png" width="100%" border="0" />

### More info
Please visit http://tosrus.frebsite.nl

### Licence
The jQuery.TosRUs plugin is licensed under the MIT license:
+ http://en.wikipedia.org/wiki/MIT_License
